# bonobo-trans
Set of ETL transformations for the Python Bonobo ETL tool

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.